import os
import hashlib
from PIL import Image
import imagehash
import numpy as np


def find_images(directory):
    """Recursively find all images in the directory."""
    images = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.lower().endswith((".jpg", ".jpeg", ".png")):
                images.append(os.path.join(root, file))
    return images


def hash_image_quick(image_path):
    """Generate a quick hash of an image."""
    with open(image_path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def hash_image_detailed(image_path):
    """Generate a perceptual hash of an image using average hashing."""
    image = Image.open(image_path)
    return imagehash.average_hash(image)


def are_images_similar(image1_path, image2_path, threshold=5):
    """Check if two images are similar based on pixel distance."""
    hash1 = hash_image_detailed(image1_path)
    hash2 = hash_image_detailed(image2_path)
    return hash1 - hash2 < threshold


def delete_duplicates(images, method="quick"):
    """Delete duplicate images based on the specified method."""
    seen_hashes = {}
    for image_path in images:
        if method == "quick":
            image_hash = hash_image_quick(image_path)
        else:
            image_hash = hash_image_detailed(image_path)

        if image_hash in seen_hashes:
            if method == "quick" or (
                method == "pixel"
                and are_images_similar(image_path, seen_hashes[image_hash])
            ):
                print(f"Deleting duplicate image: {image_path}")
                os.remove(image_path)
            else:
                seen_hashes[image_hash] = image_path
        else:
            seen_hashes[image_hash] = image_path


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Find and delete duplicate images in a directory."
    )
    parser.add_argument(
        "directory", type=str, help="The directory to search for images."
    )
    parser.add_argument(
        "--method",
        type=str,
        choices=["quick", "pixel"],
        default="quick",
        help="The method to use for finding duplicates (default: quick).",
    )

    args = parser.parse_args()
    images = find_images(args.directory)
    delete_duplicates(images, method=args.method)
